pluginid = 'plugin.video.fluxus'
host='local'